data.raw["gui-style"].default["some-luaconsole-input-textbox"] = {
    type = "textbox_style",
    name = "some-console-input-textbox",
    parent = "textbox",
    minimal_width = 700,
    minimal_height = 200,
}

data:extend({
    {
        type = "custom-input",
        name = "some-luaconsole_toggle",
        key_sequence = "CONTROL + RIGHTBRACKET"
    },
    {
        type = "custom-input",
        name = "some-luaconsole_exec",
        key_sequence = "CONTROL + RETURN"
    },
})
