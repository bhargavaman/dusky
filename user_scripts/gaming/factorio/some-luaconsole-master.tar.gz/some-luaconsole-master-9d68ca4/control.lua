function exec_command(player)
    if not player.admin then
        player.print('You are not an admin. You may not use this mod. :(')
        return
    end

    local f, lserr, pcs, pcerr, cmd

    if player.gui.screen.some_luaconsole then
        storage.cmd = player.gui.screen.some_luaconsole.input.text
    end

    cmd = storage.cmd or ""
    cmd = cmd:gsub('game%.player([^s])', 'game.players['..player.index..']%1')

    f, lserr = loadstring('local ipcs,ipcr ipcs,ipcr=pcall(function() '..cmd..' end) if not ipcs then game.players['..player.index..'].print(ipcr) end')
    if not f then
        f, lserr = loadstring('game.players['..player.index..'].print('..cmd..')')
    end

    if f then
        pcs, pcerr = pcall(f)
        if not pcs then
            player.print(pcerr:sub(1, pcerr:find('\n')))
        end
    else
        player.print(lserr:sub(1, lserr:find('\n')))
    end
end


function toggleGui (player)
    if player.gui.screen.some_luaconsole then
        storage.cmd = player.gui.screen.some_luaconsole.input.text
        player.gui.screen.some_luaconsole.destroy()
    else
        frame = player.gui.screen.add{type = 'frame', name = 'some_luaconsole', direction = 'vertical'}

        local title_flow = frame.add{type = "flow", direction = "horizontal"}
        title_flow.style.horizontally_stretchable = true
        title_flow.style.horizontal_spacing = 8

        local title_label = title_flow.add{type = 'label', caption = {'some-luaconsole.title'}, style = "frame_title"}
        title_label.drag_target = frame

        local title_pusher = title_flow.add{type = "empty-widget", style = "draggable_space_header"}
        title_pusher.style.height = 24
        title_pusher.style.horizontally_stretchable = true
        title_pusher.drag_target = frame

        local title_close_button = title_flow.add{type = "sprite-button", style = "frame_action_button", sprite = "utility/close", name = 'some-luaconsole-close', tooltip = {'some-luaconsole.close_tooltip'}}


        frame.add{type = 'label', caption = {'some-luaconsole.inputlabel'}, style = "frame_title"}


        local input = frame.add{type = 'text-box', name = 'input', style='some-luaconsole-input-textbox', enabled = admin}
        input.word_wrap = true
        input.style.maximal_height = (player.display_resolution.height/player.display_scale*0.6)
        input.text = storage.cmd or ""


        bottom_flow = frame.add{type='flow', direction='horizontal'}
        bottom_flow.style.horizontally_stretchable = true

        bottom_flow.add{type = 'button',
            name = 'some-luaconsole-close',
            style='back_button',
            caption = {'some-luaconsole.close'},
            tooltip = {'some-luaconsole.close_tooltip'}
        }
        bottom_pusher = bottom_flow.add{type = "empty-widget", style = "draggable_space_header"}
        bottom_pusher.style.height = 24
        bottom_pusher.style.horizontally_stretchable = true
        bottom_pusher.drag_target = frame

        bottom_flow.add{type = 'button',
            name = 'some-luaconsole_exec',
            style='confirm_button',
            caption = {'some-luaconsole.exec'},
            tooltip = {'some-luaconsole.exec_tooltip'},
            enabled = admin
        }


        if not player.admin then
            player.gui.screen.some_luaconsole.input.text = 'You are not an admin. You may not use this mod. :('
            player.gui.screen.some_luaconsole.input.enabled = false
        end
        frame.force_auto_center()
    end
end



script.on_event(defines.events.on_gui_click, function(event)
    if event.element.name == 'some-luaconsole_exec' then
        exec_command(game.players[event.player_index])
    elseif event.element.name == 'some-luaconsole-close' then
        toggleGui(game.players[event.player_index])
    end
end)


script.on_event('some-luaconsole_toggle', function(event)
    toggleGui(game.players[event.player_index])
end)
script.on_event('some-luaconsole_exec', function(event)
    exec_command(game.players[event.player_index])
end)
